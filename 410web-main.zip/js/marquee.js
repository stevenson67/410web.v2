$(document).ready(function() {
  $('.menu__btn').click(function(event) {
    $('body').toggleClass('lock');
  });
});
